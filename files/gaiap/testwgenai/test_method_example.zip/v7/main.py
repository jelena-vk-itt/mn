import csv


def read_csv(file_path):
    """Read a CSV file with headers into a list of dicts.
    
    Tests:
    - Missing file: should raise FileNotFoundError
    - Empty file: should raise ValueError about missing headers
    - Valid file: should return list of dicts and headers
    """
    with open(file_path, newline="", encoding="utf-8") as file_handle:
        reader = csv.DictReader(file_handle)
        headers = reader.fieldnames
        if not headers:
            raise ValueError("CSV file must include headers.")
        rows = list(reader)
    return rows, headers


def detect_numeric_columns(rows, headers):
    """Return headers whose non-empty values can be parsed as floats.
    
    A column is considered numeric if it has at least one non-empty value
    and at least 80% of non-empty values are numeric.
    
    Tests:
    - Column with all blanks: should not be considered numeric
    - Column with some blanks but all other values numeric: should be considered numeric
    - Column with non-numeric values that constitute less than 20% of non-empty values: should be considered numeric
    - Column with non-numeric values that constitute 20% or more of non-empty values: should not be considered numeric
    """
    numeric = []
    for header in headers:
        values = [row.get(header, "").strip() for row in rows]
        non_empty = [value for value in values if value != ""]
        if not non_empty:
            continue
        
        # Count how many values can be parsed as float
        numeric_count = 0
        for value in non_empty:
            try:
                float(value)
                numeric_count += 1
            except ValueError:
                pass
        
        # Check if at least 80% are numeric
        if numeric_count / len(non_empty) >= 0.8:
            numeric.append(header)
    
    return numeric


if __name__ == "__main__":
    try:
        read_csv("data.csv")
    except Exception as e:
        print("Exception while reading data.csv: ", type(e).__name__, e)
    try:
        read_csv("data2.csv")
    except Exception as e:
        print("Exception while reading data2.csv: ", type(e).__name__, e)
