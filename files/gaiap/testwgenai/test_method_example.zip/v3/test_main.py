import os
import tempfile
import unittest

from main import read_csv, detect_numeric_columns


class TestReadCsv(unittest.TestCase):

    def test_missing_file_raises_file_not_found(self):
        """Missing file: should raise FileNotFoundError"""
        with tempfile.TemporaryDirectory() as temp_dir:
            missing_path = os.path.join(temp_dir, "missing.csv")
            with self.assertRaises(FileNotFoundError):
                read_csv(missing_path)

    def test_empty_file_raises_value_error(self):
        """Empty file: should raise ValueError about missing headers"""
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "empty.csv")
            with open(file_path, "w", encoding="utf-8") as file_handle:
                file_handle.write("")
            with self.assertRaises(ValueError):
                read_csv(file_path)

    def test_valid_file_returns_rows_and_headers(self):
        """Valid file: should return list of dicts and headers"""
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "data.csv")
            with open(file_path, "w", encoding="utf-8") as file_handle:
                file_handle.write("name,age\nAlice,30\nBob,25\n")

            rows, headers = read_csv(file_path)

            self.assertEqual(headers, ["name", "age"])
            self.assertEqual(rows, [
                {"name": "Alice", "age": "30"},
                {"name": "Bob", "age": "25"}
            ])

    def test_n_file_with_only_headers_no_data(self):
        """File with only headers and no data rows should return empty list"""
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "headers_only.csv")
            with open(file_path, "w", encoding="utf-8") as file_handle:
                file_handle.write("name,age,city\n")
            
            rows, headers = read_csv(file_path)
            
            self.assertEqual(headers, ["name", "age", "city"])
            self.assertEqual(rows, [])
    
    def test_n_file_with_quoted_values_containing_commas(self):
        """File with quoted values containing commas should be parsed correctly"""
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "quoted.csv")
            with open(file_path, "w", encoding="utf-8") as file_handle:
                file_handle.write('name,address\n"Doe, John","123 Main St, Apt 4"\n')
            
            rows, headers = read_csv(file_path)
            
            self.assertEqual(headers, ["name", "address"])
            self.assertEqual(rows[0]["name"], "Doe, John")
            self.assertEqual(rows[0]["address"], "123 Main St, Apt 4")
    
    def test_n_file_with_empty_string_values(self):
        """File with empty string values should parse correctly"""
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "empty_values.csv")
            with open(file_path, "w", encoding="utf-8") as file_handle:
                file_handle.write("name,age,city\nAlice,30,\nBob,,Denver\n")
            
            rows, headers = read_csv(file_path)
            
            self.assertEqual(len(rows), 2)
            self.assertEqual(rows[0]["city"], "")
            self.assertEqual(rows[1]["age"], "")
    
    def test_n_file_with_special_characters_in_data(self):
        """File with special characters and unicode should be handled correctly"""
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "special.csv")
            with open(file_path, "w", encoding="utf-8") as file_handle:
                file_handle.write("name,notes\nJosé,Café & Naïve\nÅngela,Résumé\n")
            
            rows, headers = read_csv(file_path)
            
            self.assertEqual(len(rows), 2)
            self.assertEqual(rows[0]["name"], "José")
            self.assertEqual(rows[0]["notes"], "Café & Naïve")
    
    def test_n_file_with_multiple_rows_large_dataset(self):
        """File with many rows should return all rows correctly"""
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "large.csv")
            with open(file_path, "w", encoding="utf-8") as file_handle:
                file_handle.write("id,value\n")
                for i in range(100):
                    file_handle.write(f"{i},{i * 2}\n")
            
            rows, headers = read_csv(file_path)
            
            self.assertEqual(len(rows), 100)
            self.assertEqual(rows[0]["id"], "0")
            self.assertEqual(rows[99]["id"], "99")
            self.assertEqual(rows[99]["value"], "198")


class TestDetectNumericColumns(unittest.TestCase):

    def test_column_with_all_blanks_not_numeric(self):
        """Column with all blanks: should not be considered numeric"""
        rows = [
            {"col1": "", "col2": "10"},
            {"col1": "", "col2": "20"},
            {"col1": "", "col2": "30"}
        ]
        headers = ["col1", "col2"]
        result = detect_numeric_columns(rows, headers)
        self.assertNotIn("col1", result)
        self.assertIn("col2", result)

    def test_column_with_blanks_and_all_numeric_is_numeric(self):
        """Column with some blanks but all other values numeric: should be considered numeric"""
        rows = [
            {"col1": "10", "col2": "text"},
            {"col1": "", "col2": "text"},
            {"col1": "20", "col2": "text"},
            {"col1": "", "col2": "text"},
            {"col1": "30", "col2": "text"}
        ]
        headers = ["col1", "col2"]
        result = detect_numeric_columns(rows, headers)
        self.assertIn("col1", result)
        self.assertNotIn("col2", result)

    def test_column_with_less_than_20_percent_non_numeric_is_numeric(self):
        """Column with non-numeric values that constitute less than 20% of non-empty values:
           should be considered numeric"""
        # To be below 20%, let's have 1 non-numeric out of 6 values (16.67%)
        rows = [
            {"col1": "10"},
            {"col1": "20"},
            {"col1": "30"},
            {"col1": "40"},
            {"col1": "50"},
            {"col1": "abc"}  # 1 out of 6 = 16.67%
        ]
        headers = ["col1"]
        result = detect_numeric_columns(rows, headers)
        self.assertIn("col1", result)

    def test_column_with_more_than_20_percent_non_numeric_not_numeric(self):
        """Column with non-numeric values that constitute 20% or more of non-empty values:
           should not be considered numeric"""
        rows = [
            {"col1": "10"},
            {"col1": "20"},
            {"col1": "30"},
            {"col1": "xyz"},
            {"col1": "abc"}  # 1 out of 5 = 20%
        ]
        headers = ["col1"]
        result = detect_numeric_columns(rows, headers)
        self.assertNotIn("col1", result)

    def test_n_column_with_negative_numbers(self):
        """Column with negative numbers should be detected as numeric"""
        rows = [
            {"col1": "-10", "col2": "text"},
            {"col1": "-20.5", "col2": "text"},
            {"col1": "-30", "col2": "text"}
        ]
        headers = ["col1", "col2"]
        result = detect_numeric_columns(rows, headers)
        self.assertIn("col1", result)
        self.assertNotIn("col2", result)
    
    def test_n_column_with_decimal_numbers(self):
        """Column with decimal numbers should be detected as numeric"""
        rows = [
            {"col1": "10.5"},
            {"col1": "20.75"},
            {"col1": "30.123"}
        ]
        headers = ["col1"]
        result = detect_numeric_columns(rows, headers)
        self.assertIn("col1", result)
    
    def test_n_column_with_scientific_notation(self):
        """Column with scientific notation should be detected as numeric"""
        rows = [
            {"col1": "1e5"},
            {"col1": "2.5e-3"},
            {"col1": "3E10"}
        ]
        headers = ["col1"]
        result = detect_numeric_columns(rows, headers)
        self.assertIn("col1", result)
    
    def test_n_column_with_mixed_ints_and_floats(self):
        """Column with mix of integers and floats should be numeric"""
        rows = [
            {"col1": "10"},
            {"col1": "20.5"},
            {"col1": "30"},
            {"col1": "40.75"}
        ]
        headers = ["col1"]
        result = detect_numeric_columns(rows, headers)
        self.assertIn("col1", result)
    
    def test_n_column_with_spaces_around_numbers(self):
        """Column with leading/trailing spaces around numbers should be numeric"""
        rows = [
            {"col1": "  10  "},
            {"col1": "  20.5  "},
            {"col1": "  30  "}
        ]
        headers = ["col1"]
        result = detect_numeric_columns(rows, headers)
        self.assertIn("col1", result)
    
    def test_n_single_row_numeric(self):
        """Column with single numeric row should be detected as numeric"""
        rows = [{"col1": "42"}]
        headers = ["col1"]
        result = detect_numeric_columns(rows, headers)
        self.assertIn("col1", result)
    
    def test_n_single_row_non_numeric(self):
        """Column with single non-numeric row should not be numeric"""
        rows = [{"col1": "abc"}]
        headers = ["col1"]
        result = detect_numeric_columns(rows, headers)
        self.assertNotIn("col1", result)
    
    def test_n_multiple_columns_mixed_types(self):
        """Multiple columns with different types should be classified correctly"""
        rows = [
            {"name": "Alice", "age": "30", "salary": "50000.50", "active": "yes"},
            {"name": "Bob", "age": "25", "salary": "45000", "active": "no"},
            {"name": "Carol", "age": "35", "salary": "60000.75", "active": "yes"}
        ]
        headers = ["name", "age", "salary", "active"]
        result = detect_numeric_columns(rows, headers)
        self.assertNotIn("name", result)
        self.assertIn("age", result)
        self.assertIn("salary", result)
        self.assertNotIn("active", result)
    
    def test_n_column_exactly_80_percent_numeric(self):
        """Column with exactly 80% numeric values should be considered numeric"""
        # 4 numeric out of 5 = 80%
        rows = [
            {"col1": "10"},
            {"col1": "20"},
            {"col1": "30"},
            {"col1": "40"},
            {"col1": "text"}
        ]
        headers = ["col1"]
        result = detect_numeric_columns(rows, headers)
        self.assertIn("col1", result)
    
    def test_n_column_below_80_percent_numeric(self):
        """Column with less than 80% numeric values should not be numeric"""
        # 3 numeric out of 5 = 60%
        rows = [
            {"col1": "10"},
            {"col1": "20"},
            {"col1": "30"},
            {"col1": "text1"},
            {"col1": "text2"}
        ]
        headers = ["col1"]
        result = detect_numeric_columns(rows, headers)
        self.assertNotIn("col1", result)
    
    def test_n_mixed_positive_negative_and_decimals(self):
        """Column with mix of positive, negative, and decimal numbers should be numeric"""
        rows = [
            {"col1": "10.5"},
            {"col1": "-20"},
            {"col1": "0.5"},
            {"col1": "-30.75"}
        ]
        headers = ["col1"]
        result = detect_numeric_columns(rows, headers)
        self.assertIn("col1", result)
