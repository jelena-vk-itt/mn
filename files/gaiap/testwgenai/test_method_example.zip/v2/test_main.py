import os
import tempfile
import unittest

from main import read_csv, detect_numeric_columns


class TestReadCsv(unittest.TestCase):

    def test_missing_file_raises_file_not_found(self):
        """Missing file: should raise FileNotFoundError"""
        with tempfile.TemporaryDirectory() as temp_dir:
            missing_path = os.path.join(temp_dir, "missing.csv")
            with self.assertRaises(FileNotFoundError):
                read_csv(missing_path)

    def test_empty_file_raises_value_error(self):
        """Empty file: should raise ValueError about missing headers"""
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "empty.csv")
            with open(file_path, "w", encoding="utf-8") as file_handle:
                file_handle.write("")
            with self.assertRaises(ValueError):
                read_csv(file_path)

    def test_valid_file_returns_rows_and_headers(self):
        """Valid file: should return list of dicts and headers"""
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "data.csv")
            with open(file_path, "w", encoding="utf-8") as file_handle:
                file_handle.write("name,age\nAlice,30\nBob,25\n")

            rows, headers = read_csv(file_path)

            self.assertEqual(headers, ["name", "age"])
            self.assertEqual(rows, [
                {"name": "Alice", "age": "30"},
                {"name": "Bob", "age": "25"}
            ])


class TestDetectNumericColumns(unittest.TestCase):

    def test_column_with_all_blanks_not_numeric(self):
        """Column with all blanks: should not be considered numeric"""
        rows = [
            {"col1": "", "col2": "10"},
            {"col1": "", "col2": "20"},
            {"col1": "", "col2": "30"}
        ]
        headers = ["col1", "col2"]
        result = detect_numeric_columns(rows, headers)
        self.assertNotIn("col1", result)
        self.assertIn("col2", result)

    def test_column_with_blanks_and_all_numeric_is_numeric(self):
        """Column with some blanks but all other values numeric: should be considered numeric"""
        rows = [
            {"col1": "10", "col2": "text"},
            {"col1": "", "col2": "text"},
            {"col1": "20", "col2": "text"},
            {"col1": "", "col2": "text"},
            {"col1": "30", "col2": "text"}
        ]
        headers = ["col1", "col2"]
        result = detect_numeric_columns(rows, headers)
        self.assertIn("col1", result)
        self.assertNotIn("col2", result)

    def test_column_with_less_than_20_percent_non_numeric_is_numeric(self):
        """Column with non-numeric values that constitute less than 20% of non-empty values:
           should be considered numeric"""
        # To be below 20%, let's have 1 non-numeric out of 6 values (16.67%)
        rows = [
            {"col1": "10"},
            {"col1": "20"},
            {"col1": "30"},
            {"col1": "40"},
            {"col1": "50"},
            {"col1": "abc"}  # 1 out of 6 = 16.67%
        ]
        headers = ["col1"]
        result = detect_numeric_columns(rows, headers)
        self.assertIn("col1", result)

    def test_column_with_20_percent_or_more_non_numeric_not_numeric(self):
        """Column with non-numeric values that constitute 20% or more of non-empty values:
           should not be considered numeric"""
        rows = [
            {"col1": "10"},
            {"col1": "20"},
            {"col1": "30"},
            {"col1": "xyz"},
            {"col1": "abc"}  # 1 out of 5 = 20%
        ]
        headers = ["col1"]
        result = detect_numeric_columns(rows, headers)
        self.assertNotIn("col1", result)
