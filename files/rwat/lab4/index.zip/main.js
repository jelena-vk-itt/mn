window.addEventListener("load", (e) => {
	document.querySelector("form").addEventListener("submit", (e) => {

		// we will accumulate the data from the form into the data variable
		// each field is represented by a two-element array: it's name and its value
		let data = [];
		Array.from(document.querySelectorAll("input, select")).forEach((inp) => {
			if (inp.type == "radio") {
				// each radio button will be processed in this block, separately, as each
				// is a separate input
				if (inp.checked) {
					// in the case of a group of radio buttons, the label is the fieldset legend
					// the specified value is the label of the selected button
					data.push([getInputNameFromSection(inp), inp.labels[0].textContent]);
				}
			} else if (inp.type == "checkbox") {
				// each checkbox will be processed in this block, separately, as each
				// is a separate input

				// read the overall checkbox group label from the enclosing section
				const name = getInputNameFromSection(inp);

				// if this is the first checkbox being processed, we create  
				// an entry in the data array for the group of checkboxes
				let index = data.map(d => d[0]).indexOf(name);
				if (index == -1) {
					index = data.push([name, '']) - 1;
				}
				// now we actually add the checkbox value if it is checked
				if (inp.checked) {
					// add the checkbox label to the existing value for the checkbox group
					if (data[index][1] != '') {
						data[index][1] += ", ";
					}
					data[index][1] += inp.labels[0].textContent;
				}
			} else if (inp.type == "select-multiple") {
				// we show the value for this multi-select dropdown as a comma-separated list of selected values
				data.push([getInputNameFromSection(inp),
				Array.from(inp.options).filter(o => o.selected).map(o => o.value).join(', ')]);
			} else if (inp.type == "file") {
				// the selected file is added as an image element
				data.push([getInputNameFromOwnLabel(inp),
				inp.files.length ? "<img width=50 src=\"" + URL.createObjectURL(inp.files[0]) + "\"/>" : ""]);
			} else {
				// the simpler input fields are a straight forward name-value pair, 
				// where the label is used as the name
				const name = getInputNameFromOwnLabel(inp);
				if (name == "Password") {
					data.push([name, "************"]);
				} else {
					data.push([name, inp.value]);
				}
			}
		});

		// get the name for the complex inputs, where the label to be used is hidden in the enclosing section
		function getInputNameFromSection(el) {
			return el.closest("section").querySelector("label").textContent.replace(/[:*\s]*$/, "").trim();
		}

		function getInputNameFromOwnLabel(el) {
			return el.labels[0].textContent.replace(/[:*\s]*$/, "").trim();
		}

		// prepare the data for display to user as HTML
		function dataAsHTML() {
			let html = "";
			data.forEach(d => {
				html += 
					"<p><strong>" + d[0] + ": </strong>" + 
					(d[1] ? d[1] : "[information not provided]") + "</p>";
			});
			return html;
		}

		let contents =
			"<article>" +
			"<h1>Thank you for registering 😊</h1>" +
			"<h4>An account with the following details has been created for you: </h4>" +
			dataAsHTML() +
			"</article>";

		// set the contents of the body of the page
		document.body.innerHTML = contents;
	});
});

