(1)
Once this project is unzipped, open a console (e.g. cmd or PowerShell) in the directory containing this file and run the command

npm install

This might take time to complete but will reconstruct all the packages needed for the project.


(2)
To run the application, execute the command

npx vite

and the vite command 'o' to open the hello world application in your default browser.

