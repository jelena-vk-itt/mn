let started = false;
let count = 0;
let randomIndex = 0;

// we can make the element references static because 
// we know we will not be changing the page
// they are initiated on load below
let msgEl = null;
let boxes = null;

// set the event handlers as soon as the dom content has been loaded
document.addEventListener("DOMContentLoaded", () => {
    
    // get and store the message element dom object
    msgEl = document.getElementById("msg");

    // set a handler for the button click
    document.querySelector('button').addEventListener('click', start);

    // get and store the box element dom objects
    boxes = document.querySelectorAll('.box');

    // set handlers for clicks on the boxes
    for (let i = 0; i < boxes.length; ++i) {
        boxes[i].addEventListener('click', () => handleGuess(i));
    }
});


function start() {
    started = true;
    count = 0;
    randomIndex = Math.floor(Math.random() * 3);
    for (let box of boxes) {
        box.innerHTML = '';
    }
    msgEl.innerHTML = "Click on the boxes to find the hidden picture";
}

function handleGuess(i) {
    if (started) {
        ++count;
        if (i == randomIndex) {
            boxes[i].innerHTML = "<img src='guessing_image.jpg'>";
            msgEl.innerHTML = "You've found it on guess " + count + "!";
            started = false;
        } else {
            boxes[i].innerHTML = "Not here";
        }
    }
}

