function fixStory() {
    
    const parentArticle = document.getElementsByTagName('article')[0];

    
    // insert heading
    const heading = document.createElement("h1");
    heading.innerHTML = "Little Red Riding Hood";
    parentArticle.insertBefore(heading, parentArticle.firstElementChild);

    // remove the paragraph from different story
    parentArticle.removeChild(parentArticle.children[4]);

    // remove the answer that is in front of it question
    // then place it behind the question
    const childToMove = parentArticle.removeChild(parentArticle.children[6]);
    parentArticle.insertBefore(childToMove, parentArticle.children[7]);

    // create the ending and replace THE END with it
    const newEnd = document.createElement("p");
    newEnd.innerHTML = "However, the good hunter was passing by and heard what was happening. He was able to cut open the wolf and save both girl and granny.";
    parentArticle.replaceChild(newEnd, parentArticle.lastElementChild);
}

document.addEventListener("keypress", fixStory);


