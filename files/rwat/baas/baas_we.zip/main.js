// Import the functions you need from the SDKs you need

import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore, collection, getDocs, setDoc, deleteDoc, doc } from "firebase/firestore";

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional

const firebaseConfig = {
  apiKey: "AIzaSyCgyMwpOYjBo2NBmkvmFOR_iRRSE528Vqo",
  authDomain: "rwat-51e64.firebaseapp.com",
  projectId: "rwat-51e64",
  storageBucket: "rwat-51e64.firebasestorage.app",
  messagingSenderId: "583841527342",
  appId: "1:583841527342:web:941d87f25346f1858491bf",
  measurementId: "G-0RXVRBRWE9"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const db = getFirestore(app);

const sp = document.querySelector('.status');

sp.innerHTML = "Populating table with data... ";
const table = document.querySelector('table');
populateTable();
sp.innerHTML += "done."
await delay();

sp.innerHTML = "Writing a new row ('Uriah Heep')... ";
await setDoc(doc(db, "people", '3'), {
  name: 'Uriah', surname: 'Heep'
});
sp.innerHTML += "done."
await delay();

sp.innerHTML = "Populating table with updated data... ";
populateTable();
sp.innerHTML += "done."
await delay();

sp.innerHTML = "Deleting Uriah... ";
await deleteDoc(doc(db, "people", "3"));
sp.innerHTML += "done."
await delay();

sp.innerHTML = "Populating table with updated data... ";
populateTable();
sp.innerHTML += "done."


// ---------------------- FUNCTIONS --------------------------------
async function populateTable() {
  const people = await getDocs(collection(db, "people"));
  table.innerHTML = '';
  people.forEach((person) => {
    table.innerHTML += `<tr><td>${person.id}</td><td>${person.get("name")}</td><td>${person.get("surname")}</tr>`;
  });
}

function delay() {
  return new Promise((res) => { setTimeout(res, 3000); });
}


