document.addEventListener("DOMContentLoaded", (event) => {

    //------------------- PLACE THE SQUARE IN SAVED POSIION ----//
    let square = document.getElementById("the-square");
    let currentPosition = localStorage.getItem("square_position");
    if (currentPosition) {
	document.querySelectorAll(".flex-item")[currentPosition].appendChild(square);
    }


    //------------------- DRAGGABILITY SETUP -------------------//
    document.querySelectorAll(".flex-item").forEach((pos, i, coll) => {

        pos.addEventListener("dragover", function (e) {
            // allow the drop in any of the positions
            e.preventDefault();
        });
	
        pos.addEventListener("drop", function (e) {
            // get the position of the square that is being dragged from the data transfer
	    e.target.appendChild(document.getElementById("the-square"));
	    localStorage.setItem("square_position", i);
        });
    });

    //------------------- EVENT HANDLER FOR CLICK ON PAGE ------//
    document.body.addEventListener('click', () => {
        document.body.style.backgroundColor = "rgb(" + 
            Math.floor(Math.random() * 256) + "," +
            Math.floor(Math.random() * 256) + "," +
            Math.floor(Math.random() * 256) + ")";
    });
});

    
