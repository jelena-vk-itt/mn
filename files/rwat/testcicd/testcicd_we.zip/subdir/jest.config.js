export default { 
    testEnvironment: "jsdom",
    testMatch: "**/*.test.js",
    moduleFileExtensions: ["js"],
}
