
import { addCounter } from './counter.js';

test('counter creation and operation', () => {
    document.body.innerHTML = `<div><p>Test</p><p>Test 2></div>`;
    const hostElement = document.querySelector('div');
    addCounter(hostElement);
    const counterDiv = hostElement.lastElementChild;
    expect(counterDiv).not.toBeNull();
    expect(counterDiv.style.color).toBe('red');
    expect(counterDiv.style.fontWeight).toBe('bold');
    expect(counterDiv.innerHTML).toBe('Click count: 0');
    counterDiv.click();
    expect(counterDiv.innerHTML).toBe('Click count: 1');
    counterDiv.click();
    counterDiv.click();
    expect(counterDiv.innerHTML).toBe('Click count: 3');
});
  