import { addCounter } from './counter.js';

addCounter(document.querySelector('h1'));
addCounter(document.querySelector('p'));