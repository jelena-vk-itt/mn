The directory that contains this readme corresponds to a GitHub repository, for example the RWAT repository.

The directory subdir is an npm project directory. In the assignment, it corresponds to the ca2 directory. To reconstruct the node_modules run 'npm install' from the command line in that directory.