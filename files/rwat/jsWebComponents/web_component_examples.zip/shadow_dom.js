// ============== CREATE Shadow DOM =====================
// creating a shadow DOM with JavaScript
const shadowHost = document.getElementById("shadow-host");
const shadowRoot = shadowHost.attachShadow({ mode: "open" });
const pgph = document.createElement("p");
pgph.appendChild(document.createTextNode("Hello from the shadow DOM!"));
shadowRoot.appendChild(pgph);

// ============== Styling =====================
// styling paragraphs from the outside of the shadow DOM in the usual way will 
// not reach the shadow DOM
const pgphs = document.getElementsByTagName('p');
for (const p of pgphs) {
	p.style.textDecoration = 'underline';
}

// to style paragraphs in shadow DOM from the outside, shadow hosts must be 
// explicitly queried for paragraphs inside them
const shadowHosts = document.querySelectorAll('[id^=shadow-host]');
for (const sh of shadowHosts) {
	const shPgphs = sh.shadowRoot.querySelectorAll('p');
	for (const p of shPgphs) {
		p.style.color = 'green';
	}
}

// elements in a shadow DOM can be styled also by programmatically attaching a CSS
// style sheet to the shadow DOM:
const cssSheet = new CSSStyleSheet();
cssSheet.replaceSync("p { border: 2px dotted blue;}");
document.getElementById("shadow-host").shadowRoot.adoptedStyleSheets = [cssSheet];
