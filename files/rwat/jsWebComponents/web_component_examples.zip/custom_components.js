// helper function
function get_width(node) {
    var range = document.createRange();
    range.selectNodeContents(node);
    return range.getClientRects()[0].width;
}

// =========== CUSTOM ELEMENT THAT BUILDS SHADOW DOM  =============== //

// define custom element and add to the customElements list
class XSeparator extends HTMLElement {
    constructor() {
        super();
    }

    // create the element content when it is connected into the page
    connectedCallback() {
        const shadow = this.attachShadow({ mode: "open" });
        const sep = document.createElement('div');
        let colour = this.getAttribute('colour');
        if (!colour) colour = 'black';
        sep.style.border = "1px solid " + colour;
        sep.style.color = colour;
        sep.style.textAlign = 'center';
        shadow.appendChild(sep);

        this.adjustContent(sep);
        window.addEventListener("resize", () => { this.adjustContent(sep); });
    }

    // a move should not recreate the element
    connectedMoveCallback() { }


    // this function adjusts the number of x characters depending on the width of the parent
    adjustContent(sep) {
        sep.innerHTML = 'X';
        while (get_width(sep.firstChild) < sep.offsetWidth) {
            sep.innerHTML += 'X';
        }
        sep.innerHTML = sep.innerHTML.substring(1);
    }
}
customElements.define("x-sep", XSeparator);


// ================= CUSTOM ELEMENT WITH TEMPLATE IN SHADOW DOM  ================= //

// this time we register an anonymous class (with no name) as a custom component
customElements.define("x-p", class extends HTMLElement {
    constructor() {
        super();

        let templateContent = document.getElementById("x-p-template").content;

        const shadowRoot = this.attachShadow({ mode: "open" });
        shadowRoot.appendChild(templateContent.cloneNode(true));
    }
});

