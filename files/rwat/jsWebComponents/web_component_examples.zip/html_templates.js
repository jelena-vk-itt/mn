// cloning and inserting a template
let t = document.getElementById("example-template");
let content = t.content;
let h = document.getElementById("template-insertion-host");
h.appendChild(content.cloneNode(true));
h.appendChild(content.cloneNode(true));
