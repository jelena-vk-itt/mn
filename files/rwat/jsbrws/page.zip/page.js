
function changePage () {
    document.getElementById("pgtt").innerHTML = "TU Dublin Wallpaper"
    document.getElementsByTagName("p")[0].style.color = "red"
}

console.log("Function changePage has been defined.")
document.getElementById("pgtt").insertAdjacentText("beforeend", " So Blue")

