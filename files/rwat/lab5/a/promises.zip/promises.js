function getNewPromise(value, delay) {
   return new Promise((resolve, reject) => {
      setTimeout(() => {
         resolve(value);
      }, delay);
   });
}

getNewPromise("Hello from promise!", 3000).then(value => {
   let pgph = document.createElement("p");
   pgph.appendChild(document.createTextNode(value));
   document.body.appendChild(pgph);
});

getNewPromise("abcdefg", 3000).then(value => {
      return value.toUpperCase(); 
   })
   .then(value => {
      return value.split('').reverse().join("")
   })
   .then(value => {
      let pgph = document.createElement("p");
      pgph.appendChild(document.createTextNode(value));
      document.body.appendChild(pgph);
   });


getNewPromise(42, 3000)
   .then(result => result * 2)
   .then(result => {
      getNewPromise(result + 16, 1000)
         .then(result => console.log("Nested result: ", result))
         .catch((e) => { })
      throw "Boo!";
   })
   .then(result => console.log("Final result: ", result * -1))
   .catch((e) => console.error("Failed: ", e.message));

