package lab11.company;

public class InvolvedParty {
    private static int nextId = 1;
    protected int id;
    protected String name;
    protected String emailAddress;

    InvolvedParty(String name, String emailAddress) {
        this.id = nextId++;
        this.name = name;
        this.emailAddress = emailAddress;
    }
}
