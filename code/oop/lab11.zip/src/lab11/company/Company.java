package lab11.company;

import lab11.customers.Customers;
import lab11.suppliers.Suppliers;
import lab11.orders.IncomingOrder;
import lab11.orders.OutgoingOrder;

public class Company {
    private final String VAT_NUMBER;
    private Customers customers = new Customers();
    private Suppliers suppliers = new Suppliers();

    public Company(String vatNumber) {
        this.VAT_NUMBER = vatNumber;
    }
    void addPersonCustomer(String name, String email) {
        customers.add(new PersonCustomer(name, email));
    }
    void addOrganisationCustomer(String name, String email, String contactName) {
        customers.add(new OrganisationCustomer(name, email, contactName, VAT_NUMBER));
    }
    void addOrganisationSupplier(String name, String email, String contactName) {
        suppliers.add(new OrganisationSupplier(name, email, contactName));
    }
    public static void main(String args[]) {
        Company company = new Company("XYZ123456");
        company.addPersonCustomer("Joe Bloggs", "jb@gm.com");
        company.addPersonCustomer("Jane Cloggs", "jc@yh.ie");
        company.addOrganisationCustomer("Cards", "mm@cards.com", "Minnie Moggs");
        company.addOrganisationSupplier("WoodCo", "bb@wood.com", "Bobby Briggs");
        company.addOrganisationSupplier("Glue", "info@glue.com", "Maxie Maggs");

        System.out.println("===== SENDING RECEIPTS =====\n");
        company.customers.sendReceipts(new IncomingOrder[] {
            new IncomingOrder(1, "Card 100 10x15", 7),
            new IncomingOrder(2, "Card 100 10x15", 7),
            new IncomingOrder(3, "Card 1000 10x15", 50)
        });

        System.out.println("===== SENDING ORDERS =====\n");
            company.suppliers.sendOrders(new OutgoingOrder[] {
            new OutgoingOrder(4, "Wood 1x3", 10),
            new OutgoingOrder(5, "Glue 5l", 2)
        });
    } 
}
