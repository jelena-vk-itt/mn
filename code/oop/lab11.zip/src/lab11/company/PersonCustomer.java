package lab11.company;

import lab11.customers.Customer;
import lab11.emails.EmailSystem;

public class PersonCustomer extends Person implements Customer {

    public PersonCustomer(String name, String emailAddress) {
        super(name, emailAddress, "");
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public void sendReceipt(String item, int price) {
        EmailSystem.sendEmail(emailAddress, "Receipt for " + item,
            "Dear " + name + ",\n" +
            "Thank you for your purchase.\n" +
            "Receipt for: " + item + "\n" +
            "Price: " + price + "\n");
    }
}