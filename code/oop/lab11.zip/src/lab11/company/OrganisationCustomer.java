package lab11.company;

import lab11.emails.EmailSystem;
import lab11.customers.Customer;

public class OrganisationCustomer extends Organisation implements Customer {
    private String vatNumber;

    OrganisationCustomer(String name, String emailAddress, String contactName, String vatNumber) {
        super(name, emailAddress, contactName);
        this.vatNumber = vatNumber;
    }   
    
    @Override
    public int getId() {
        return id;
    }

    @Override
    public void sendReceipt(String item, int price) {
       EmailSystem.sendEmail(emailAddress, "Receipt for " + item,
            "Dear " + contactName + ",\n" +
            "Thank you for your purchase.\n" +
            "VAT Number: " + vatNumber + "\n" +
            "Net price: " + String.format("%.2f", (double)(price * 0.8)) + "\n" +
            "VAT: " + String.format("%.2f", (double)(price * 0.2)) + "\n");           
    }
}