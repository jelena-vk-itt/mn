package lab11.company;

public class Organisation extends InvolvedParty {
    protected String contactName;

    Organisation(String name, String emailAddress, String contactName) {
        super(name, emailAddress);
        this.contactName = contactName;
    }
}