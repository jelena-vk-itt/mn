package lab11.company;

public class Person extends InvolvedParty {
    String dob;

    Person(String name, String emailAddress, String dob) {
        super(name, emailAddress);
        this.dob = dob;
    }
}