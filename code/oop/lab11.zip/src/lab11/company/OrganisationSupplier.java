package lab11.company;

import lab11.emails.EmailSystem;
import lab11.suppliers.Supplier;

public class OrganisationSupplier extends Organisation implements Supplier {

    OrganisationSupplier(String name, String emailAddress, String contactName) {
        super(name, emailAddress, contactName);
        this.contactName = contactName;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public void sendOrder(String item, int quantity) {
        EmailSystem.sendEmail(emailAddress, "Order for " + item,
            "Dear " + contactName + ",\n" +
            "Could you please supply us with the following:\n" +
            "item: " + item + "\n" +
            "quantity: " + quantity + "\n");
    }
    
}