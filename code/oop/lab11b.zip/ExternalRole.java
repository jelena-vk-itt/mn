public interface ExternalRole {
    int getId();
}