public class EmailSystem {
    static public void sendEmail(String address, String subject, String body) {
        System.out.println("To: " + address);
        System.out.println("Subject: " + subject);
        System.out.println("\n" + body);
    }
}
