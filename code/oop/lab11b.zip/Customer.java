public interface Customer extends ExternalRole {
    void sendReceipt(String item, int price);
}
