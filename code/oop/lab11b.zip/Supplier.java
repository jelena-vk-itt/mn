public interface Supplier extends ExternalRole {
    void sendOrder(String item, int quantity); 
}
