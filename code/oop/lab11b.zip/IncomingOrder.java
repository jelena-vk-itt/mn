public record IncomingOrder(int customerId, String item, int price){} 
